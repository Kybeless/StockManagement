using MySqlConnector;
using System;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace StockManagementProject
{
    public partial class Login : Form
    {
        private MySqlConnection conn;

        public Login()
        {
            InitializeComponent();
            InitializeDatabaseConnection();

        }

        private void InitializeDatabaseConnection()
        {
            string conUrl = "Server=localhost;User ID=root;Password=;Database=20200305018";
            conn = new MySqlConnection(conUrl);
        }

        private bool loggedInSuccessfully = false;

        private void ExecuteQuery()
        {
            string username = textUser.Text;
            string password = textPassword.Text;

            string command = "SELECT Username, Password FROM login WHERE Username = @Username AND Password = @Password";

            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(command, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);

                MySqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    Console.WriteLine("Giri� ba�ar�l�.");
                    loggedInSuccessfully = true;
                }
                else
                {
                    Console.WriteLine("Kullan�c� ad� veya �ifre yanl��.");
                    MessageBox.Show("Kullan�c� ad� veya �ifre yanl��.");
                }

                reader.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Hata: " + e.Message);
                MessageBox.Show("Veritaban� hatas�: " + e.Message);
            }
            finally
            {
                conn.Close();
            }
        }




        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void PasswordLabel_Click(object sender, EventArgs e)
        {

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textUser.Text) || string.IsNullOrEmpty(textPassword.Text))
            {
                MessageBox.Show("Kullan�c� ad� ve �ifre alanlar� bo� olamaz.");
                return;
            }

            ExecuteQuery(); // Veritaban� sorgusu yap�l�yor

            // Do�ru giri� yap�ld���nda men� formunu a�
            if (loggedInSuccessfully)
            {
                Menu menu = new Menu();
                menu.Show();
                this.Hide(); // Form1'i gizle
            }
        }


        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textUser_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textPassword_TextChanged(object sender, EventArgs e)
        {
            textPassword.PasswordChar = '*';
        }
    }
}
