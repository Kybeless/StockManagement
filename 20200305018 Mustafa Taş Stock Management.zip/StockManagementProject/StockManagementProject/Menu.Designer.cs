﻿namespace StockManagementProject
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            stockmanagementButton = new Button();
            exitButton = new Button();
            backButton = new Button();
            SuspendLayout();
            // 
            // stockmanagementButton
            // 
            stockmanagementButton.Location = new Point(21, 12);
            stockmanagementButton.Name = "stockmanagementButton";
            stockmanagementButton.Size = new Size(75, 23);
            stockmanagementButton.TabIndex = 0;
            stockmanagementButton.Text = "Stock Management";
            stockmanagementButton.UseVisualStyleBackColor = true;
            stockmanagementButton.Click += stockmanagementButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(21, 113);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 23);
            exitButton.TabIndex = 1;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // backButton
            // 
            backButton.Location = new Point(21, 60);
            backButton.Name = "backButton";
            backButton.Size = new Size(75, 23);
            backButton.TabIndex = 2;
            backButton.Text = "Back";
            backButton.UseVisualStyleBackColor = true;
            backButton.Click += backButton_Click;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(120, 164);
            Controls.Add(backButton);
            Controls.Add(exitButton);
            Controls.Add(stockmanagementButton);
            Name = "Menu";
            Text = "Menu";
            ResumeLayout(false);
        }

        #endregion

        private Button stockmanagementButton;
        private Button exitButton;
        private Button backButton;
    }
}