﻿using MySqlConnector;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace StockManagementProject
{
    public partial class StockManagement : Form
    {
        private string connectionString = "Server=localhost;Database=20200305018;Uid=root;Pwd=;";

        private TextBox searchTextBox;

        public StockManagement()
        {
            InitializeComponent();
            UpdateData();
        }

        private void UpdateData()
        {
            string selectQuery = "SELECT `Product ID`, `Product Name`, `Product Price`, `Unit Price` FROM products";

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    using (var cmd = new MySqlCommand(selectQuery, connection))
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dataGridView1.DataSource = dt;

                            dataGridView1.Columns["Product ID"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                            dataGridView1.Columns["Product Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                            dataGridView1.Columns["Product Price"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                            dataGridView1.Columns["Unit Price"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }





        private void addButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            decimal productID = decimal.Parse(textBox1.Text);
            string productName = textBox2.Text;
            decimal productPrice = decimal.Parse(textBox3.Text);
            decimal unitPrice = decimal.Parse(textBox4.Text);

            string insertQuery = "INSERT INTO products (`Product ID`, `Product Name`, `Product Price`, `Unit Price`) VALUES (@ProductID, @ProductName, @ProductPrice, @UnitPrice)";

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    using (var cmd = new MySqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ProductID", productID);
                        cmd.Parameters.AddWithValue("@ProductName", productName);
                        cmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                        cmd.Parameters.AddWithValue("@UnitPrice", unitPrice);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data added successfully.");
                            UpdateData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add data.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }






        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            decimal unitPrice = decimal.Parse(dataGridView1.SelectedRows[0].Cells["Unit Price"].Value.ToString());

            string deleteQuery = "DELETE FROM products WHERE `Unit Price` = @UnitPrice";

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    using (var cmd = new MySqlCommand(deleteQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@UnitPrice", unitPrice);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data deleted successfully.");
                            UpdateData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete data.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }





        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void productLabel_Click(object sender, EventArgs e)
        {

        }

        private void productNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void ProductPriceLabel_Click(object sender, EventArgs e)
        {

        }

        private void UnitPriceLabel_Click(object sender, EventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            Menu menuForm = new Menu();
            menuForm.Show();
            this.Hide();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to update.");
                return;
            }

            // Seçilen satırın birim fiyatını alın
            decimal unitPrice = decimal.Parse(dataGridView1.SelectedRows[0].Cells["Unit Price"].Value.ToString());

            // Yeni değerleri alın
            decimal newProductID = decimal.Parse(textBox1.Text);
            string newProductName = textBox2.Text;
            decimal newProductPrice = decimal.Parse(textBox3.Text);
            decimal newUnitPrice = decimal.Parse(textBox4.Text);

            // Bağlantıyı aç
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                // UPDATE sorgusunu hazırla ve çalıştır
                string updateQuery = "UPDATE products SET `Product ID` = @NewProductID, `Product Name` = @NewProductName, `Product Price` = @NewProductPrice, `Unit Price` = @NewUnitPrice WHERE `Unit Price` = @UnitPrice";
                using (var cmd = new MySqlCommand(updateQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@NewProductID", newProductID);
                    cmd.Parameters.AddWithValue("@NewProductName", newProductName);
                    cmd.Parameters.AddWithValue("@NewProductPrice", newProductPrice);
                    cmd.Parameters.AddWithValue("@NewUnitPrice", newUnitPrice);
                    cmd.Parameters.AddWithValue("@UnitPrice", unitPrice);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data updated successfully.");
                        UpdateData(); // Verileri güncelle
                    }
                    else
                    {
                        MessageBox.Show("Failed to update data.");
                    }
                }
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
